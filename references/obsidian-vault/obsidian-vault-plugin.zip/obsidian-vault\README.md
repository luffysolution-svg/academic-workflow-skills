# Obsidian Vault

Local Codex plugin for maintaining Obsidian vaults as persistent linked wikis.

![Canvas demo](./assets/screenshots/canvas-demo.png)

It provides:

- MCP tools for vault file listing, search, reading, writing, note creation, and YAML property updates.
- Wikilink helpers for adding related links and building backlink-aware graph data.
- JSON Canvas creation for visual maps and Obsidian Bases creation for table/card/list views.
- A safe wrapper around the local `obsidian` CLI when Obsidian Desktop is installed and running.
- A workflow skill that composes this plugin with `obsidian-markdown`, `json-canvas`, and `obsidian-bases`.

## Demo

The current demo uses existing Obsidian notes about SMART/styrene process design:

- A hub note with YAML properties, tags, and wikilinks.
- A Canvas graph connecting Zotero metadata, a MinerU paper extraction, progress notes, and utilities notes.
- A Base table/card view over SMART-related notes and generated artifacts.

![Hub note demo](./assets/screenshots/hub-note-demo.png)

![Base demo](./assets/screenshots/base-demo.png)

## Design References

This plugin intentionally borrows ideas from two references:

- [Kepano's Obsidian Skills](https://github.com/kepano/obsidian-skills): the domain is split into Obsidian Markdown, JSON Canvas, Bases, CLI, and extraction-oriented workflows. This plugin follows that modular approach, then bundles the common local vault operations behind MCP tools.
- [Karpathy's LLM Wiki](https://gist.github.com/karpathy/442a6bf555914893e9891c11519de94f): the vault is treated as a persistent, compounding wiki maintained by an LLM. The plugin supports that pattern with hub notes, wikilinks, graph checks, index/log-friendly workflows, Canvas maps, and Bases views.

See [References and Attribution](./docs/REFERENCES.md) for the fuller rationale.

## Configure

Set `OBSIDIAN_VAULT_PATH` in `.mcp.json`, or pass `vault_path` to each tool call. The default value is `auto`, which asks the local Obsidian CLI for the currently active vault path and falls back to the process working directory if the CLI is unavailable.

```json
{
  "OBSIDIAN_VAULT_PATH": "auto",
  "OBSIDIAN_CLI_COMMAND": "obsidian"
}
```

The CLI wrapper expects Obsidian 1.12.7 or newer and the `obsidian` command on PATH.

By default, paths must resolve to a folder containing `.obsidian`. Set `OBSIDIAN_ALLOW_NON_VAULT=true` only when intentionally using a plain Markdown folder.

## Install Dependencies

The MCP server is Python-based:

```bash
python -m pip install -r requirements.txt
```

`PyYAML` is recommended for full YAML compatibility. The plugin has a small fallback parser for simple frontmatter and Bases files, but publishing should include the dependency.

## Portability Notes

- The plugin does not hard-code a vault path. `auto` follows the vault currently active in the local Obsidian CLI.
- All file operations are constrained to the resolved vault root.
- Existing files are not overwritten unless the tool call passes `overwrite=true`.
- Obsidian CLI features require Obsidian Desktop to be running. Direct file tools still work when the CLI is unavailable if `OBSIDIAN_VAULT_PATH` is set.
- `.mcp.json` uses `${CLAUDE_PLUGIN_ROOT}` because that is the plugin-root variable supported by current local plugin examples. If your host uses a different variable, update the script path before publishing.

## Publish Checklist

Before sharing this plugin with other people:

- Replace `repository` in `.codex-plugin/plugin.json` with the real source repository.
- Replace `author` and policy URLs with your own project metadata if publishing publicly.
- Include this directory as `plugins/obsidian-vault` or publish it through a marketplace entry that points to the same plugin root.
- Test on a clean machine with `OBSIDIAN_VAULT_PATH=auto` and with an explicit vault path containing non-ASCII characters.
- Confirm Obsidian 1.12.7+ and the `bases`, `canvas`, and `properties` core plugins are enabled when testing app-backed features.

See [Deployment Guide](./docs/DEPLOYMENT.md) for a GitHub publishing flow.

## Useful Prompts

- "Show me the structure of this Obsidian vault."
- "Create a linked wiki note with YAML properties."
- "Add wikilinks between these notes and report orphans."
- "Create a Canvas map of this topic cluster."
- "Create a Base view for all project notes."

## References

- Kepano's Obsidian skills split the domain into Markdown, Bases, Canvas, CLI, and extraction skills: https://github.com/kepano/obsidian-skills
- Karpathy's LLM Wiki pattern frames Obsidian as an IDE for a persistent, LLM-maintained wiki: https://gist.github.com/karpathy/442a6bf555914893e9891c11519de94f
- Obsidian CLI documentation: https://help.obsidian.md/cli
