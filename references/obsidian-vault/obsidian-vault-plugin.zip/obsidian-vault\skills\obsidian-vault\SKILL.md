---
name: obsidian-vault
description: Use this skill when the user asks to inspect, edit, organize, or maintain a local Obsidian vault, including vault files, YAML properties, tags, wikilinks, backlinks, graph structure, JSON Canvas, Bases, or the Obsidian CLI.
---

# Obsidian Vault

Use the bundled `obsidian-vault` MCP tools for local vault operations, and combine them with the workspace skills `obsidian-markdown`, `json-canvas`, and `obsidian-bases` when creating Obsidian-native content.

## Setup

The plugin reads `OBSIDIAN_VAULT_PATH` from `.mcp.json` when set. The default value is `auto`, which resolves the currently active Obsidian CLI vault. If `auto` cannot resolve a vault, pass `vault_path` explicitly to tools or set `OBSIDIAN_VAULT_PATH` to the vault root. The path should usually contain `.obsidian`.

If Obsidian Desktop 1.12.7 or newer is installed and running, the tool `obsidian_cli` can call the local `obsidian` command. The CLI is useful for app-backed actions such as opening notes, querying Bases, listing backlinks, setting properties through Obsidian, taking screenshots, and running developer commands.

## Core Workflow

1. Inspect the vault with `obsidian_vault_status`, `obsidian_list_files`, and `obsidian_search`.
2. Read candidate notes with `obsidian_read_file`.
3. Edit Markdown using Obsidian-flavored syntax:
   - YAML properties at the top of notes.
   - Wikilinks like `[[Topic]]`, `[[Topic|label]]`, and embeds like `![[Diagram.canvas]]`.
   - Stable tags in frontmatter, using nested tags when they clarify structure.
4. Update properties with `obsidian_update_properties` instead of manually rewriting frontmatter when possible.
5. Add controlled links with `obsidian_add_wikilinks` and then run `obsidian_build_graph` to check backlinks, dead ends, and orphan notes.
6. Create Canvas files with `obsidian_create_canvas` when a visual map is useful.
7. Create Bases files with `obsidian_create_base` when the user needs table/card/list views over notes.
8. Use `obsidian_cli` for Obsidian app behavior that direct file editing cannot guarantee.

## Persistent Wiki Pattern

For LLM-maintained wiki work:

- Keep raw sources separate from generated wiki notes.
- Maintain an `index.md` with each important page, one-line summaries, and major categories.
- Maintain a chronological `log.md` with entries for ingest, query, and lint passes.
- When ingesting a source, update the source summary, touched entity pages, concept pages, index, and log in the same pass.
- Prefer durable cross-references over one-off summaries. New insights should be filed back into the vault when they are likely to matter later.
- Periodically run graph checks for orphan pages, dead ends, unresolved links, missing backlinks, stale claims, and concepts that deserve their own pages.

## Tool Hints

- `obsidian_list_files`: scan Markdown, Canvas, Bases, and attachments.
- `obsidian_search`: search note contents with line snippets.
- `obsidian_read_file` / `obsidian_write_file`: read or create any vault-relative file.
- `obsidian_create_note`: create a Markdown note with title and frontmatter.
- `obsidian_update_properties`: merge, replace, or remove YAML properties.
- `obsidian_add_wikilinks`: append related links or replace exact phrases with wikilinks.
- `obsidian_build_graph`: parse `[[wikilinks]]`, backlinks, tags, orphans, and dead ends.
- `obsidian_create_canvas`: write valid JSON Canvas from node and edge JSON.
- `obsidian_create_base`: write valid Obsidian Bases YAML from JSON.
- `obsidian_cli`: call commands such as `files`, `read`, `search`, `property:set`, `base:query`, `links`, `backlinks`, `orphans`, `open`, `dev:screenshot`, and `eval`.

## Safety Rules

- Treat all file paths as vault-relative unless the tool explicitly asks for `vault_path`.
- Do not write outside the vault root.
- Do not use a plain Markdown folder unless `OBSIDIAN_ALLOW_NON_VAULT=true` was set intentionally.
- Preserve existing note body content and unrelated properties.
- For bulk changes, read the graph first, make focused edits, then rebuild the graph to confirm the shape changed as intended.
- Prefer Obsidian CLI `move` or `rename` for note moves when Obsidian is running, because it can update internal links according to vault settings.
