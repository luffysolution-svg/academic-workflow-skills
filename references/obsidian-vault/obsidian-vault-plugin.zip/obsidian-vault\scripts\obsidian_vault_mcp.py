from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
from pathlib import Path
from typing import Any

from mcp.server.fastmcp import FastMCP


DEFAULT_EXCLUDES = {".git", ".obsidian", ".trash", "node_modules", ".DS_Store"}
WIKILINK_RE = re.compile(r"(?<!!)\[\[([^\]\n]+)\]\]")
EMBED_RE = re.compile(r"!\[\[([^\]\n]+)\]\]")

mcp = FastMCP("obsidian-vault")


def _json(value: str, default: Any) -> Any:
    if not value or not value.strip():
        return default
    try:
        return json.loads(value)
    except json.JSONDecodeError as exc:
        raise ValueError(f"Expected valid JSON: {exc}") from exc


def _vault(vault_path: str = "") -> Path:
    selected = vault_path or os.environ.get("OBSIDIAN_VAULT_PATH") or "auto"
    if selected.strip().lower() == "auto":
        selected = _active_cli_vault_path()
        if not selected:
            cwd = Path(os.getcwd()).resolve()
            if _is_vault_root(cwd):
                selected = str(cwd)
            else:
                raise RuntimeError(
                    "Could not resolve an Obsidian vault. Open Obsidian with a vault, "
                    "set OBSIDIAN_VAULT_PATH to a vault root, pass vault_path explicitly, "
                    "or run from a directory containing .obsidian."
                )
    path = Path(selected).expanduser().resolve()
    if not path.exists():
        raise FileNotFoundError(f"Vault path does not exist: {path}")
    if not path.is_dir():
        raise NotADirectoryError(f"Vault path is not a directory: {path}")
    if not _is_vault_root(path) and os.environ.get("OBSIDIAN_ALLOW_NON_VAULT", "").lower() not in {"1", "true", "yes"}:
        raise ValueError(
            f"Path does not look like an Obsidian vault root because it has no .obsidian folder: {path}. "
            "Set OBSIDIAN_ALLOW_NON_VAULT=true to allow plain folders."
        )
    return path


def _is_vault_root(path: Path) -> bool:
    return (path / ".obsidian").is_dir()


def _active_cli_vault_path() -> str:
    cli = os.environ.get("OBSIDIAN_CLI_COMMAND", "obsidian")
    if shutil.which(cli) is None:
        return ""
    try:
        completed = subprocess.run(
            [cli, "vault", "info=path"],
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=5,
        )
    except Exception:
        return ""
    if completed.returncode != 0:
        return ""
    return completed.stdout.strip()


def _safe_path(vault: Path, rel_path: str) -> Path:
    if not rel_path:
        raise ValueError("A vault-relative path is required.")
    normalized = rel_path.replace("\\", "/").lstrip("/")
    candidate = Path(normalized)
    full = candidate if candidate.is_absolute() else vault / candidate
    full = full.expanduser().resolve()
    try:
        full.relative_to(vault)
    except ValueError as exc:
        raise ValueError(f"Path escapes the vault root: {rel_path}") from exc
    return full


def _rel(vault: Path, path: Path) -> str:
    return path.resolve().relative_to(vault).as_posix()


def _iter_files(vault: Path, folder: str = "", include_hidden: bool = False):
    root = _safe_path(vault, folder) if folder else vault
    if not root.exists():
        return
    if root.is_file():
        yield root
        return
    for path in root.rglob("*"):
        if not include_hidden and any(part in DEFAULT_EXCLUDES or part.startswith(".") for part in path.relative_to(vault).parts):
            continue
        if path.is_file():
            yield path


def _extension_set(extensions: str) -> set[str]:
    if not extensions.strip():
        return set()
    result = set()
    for part in extensions.split(","):
        ext = part.strip().lower()
        if not ext:
            continue
        result.add(ext if ext.startswith(".") else f".{ext}")
    return result


def _read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8-sig")


def _write_text(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8", newline="\n")


def _split_frontmatter(text: str) -> tuple[dict[str, Any], str]:
    if not text.startswith("---"):
        return {}, text
    lines = text.splitlines(keepends=True)
    if not lines or lines[0].strip() != "---":
        return {}, text
    for index in range(1, len(lines)):
        if lines[index].strip() == "---":
            raw = "".join(lines[1:index])
            body = "".join(lines[index + 1 :])
            return _load_yaml(raw), body
    return {}, text


def _load_yaml(raw: str) -> dict[str, Any]:
    try:
        import yaml  # type: ignore

        value = yaml.safe_load(raw) if raw.strip() else {}
        return value if isinstance(value, dict) else {}
    except Exception:
        return _load_simple_yaml(raw)


def _load_simple_yaml(raw: str) -> dict[str, Any]:
    data: dict[str, Any] = {}
    current_key: str | None = None
    for line in raw.splitlines():
        if not line.strip() or line.lstrip().startswith("#"):
            continue
        if line.startswith((" ", "\t")) and current_key:
            stripped = line.strip()
            if stripped.startswith("- "):
                data.setdefault(current_key, [])
                if isinstance(data[current_key], list):
                    data[current_key].append(_parse_scalar(stripped[2:].strip()))
            continue
        if ":" not in line:
            continue
        key, value = line.split(":", 1)
        key = key.strip()
        value = value.strip()
        current_key = key
        data[key] = [] if value == "" else _parse_scalar(value)
    return data


def _parse_scalar(value: str) -> Any:
    if value in {"true", "True"}:
        return True
    if value in {"false", "False"}:
        return False
    if value in {"null", "Null", "~"}:
        return None
    if value.startswith("[") and value.endswith("]"):
        inner = value[1:-1].strip()
        if not inner:
            return []
        return [_parse_scalar(part.strip()) for part in inner.split(",")]
    if (value.startswith('"') and value.endswith('"')) or (value.startswith("'") and value.endswith("'")):
        return value[1:-1]
    try:
        if "." in value:
            return float(value)
        return int(value)
    except ValueError:
        return value


def _dump_yaml(data: dict[str, Any]) -> str:
    try:
        import yaml  # type: ignore

        return yaml.safe_dump(data, sort_keys=False, allow_unicode=True).strip()
    except Exception:
        return _dump_simple_yaml(data)


def _dump_simple_yaml(data: dict[str, Any]) -> str:
    lines: list[str] = []
    for key, value in data.items():
        if isinstance(value, list):
            lines.append(f"{key}:")
            for item in value:
                lines.append(f"  - {_format_scalar(item)}")
        else:
            lines.append(f"{key}: {_format_scalar(value)}")
    return "\n".join(lines)


def _format_scalar(value: Any) -> str:
    if value is True:
        return "true"
    if value is False:
        return "false"
    if value is None:
        return "null"
    if isinstance(value, (int, float)):
        return str(value)
    text = str(value)
    if not text or any(ch in text for ch in [":", "#", "[", "]", "{", "}", "\n"]) or text.strip() != text:
        return json.dumps(text, ensure_ascii=False)
    return text


def _join_frontmatter(properties: dict[str, Any], body: str) -> str:
    if not properties:
        return body.lstrip("\n")
    return f"---\n{_dump_yaml(properties)}\n---\n\n{body.lstrip()}"


def _note_title_from_path(rel_path: str) -> str:
    return Path(rel_path).stem.replace("_", " ").replace("-", " ").strip() or "Untitled"


def _target_from_link(link: str) -> str:
    target = link.split("|", 1)[0].split("#", 1)[0].strip()
    return target[:-3] if target.lower().endswith(".md") else target


def _normalize_note_key(path_or_name: str) -> str:
    value = path_or_name.replace("\\", "/").strip()
    if value.lower().endswith(".md"):
        value = value[:-3]
    return value.lower()


def _collect_markdown(vault: Path) -> list[Path]:
    return [path for path in _iter_files(vault) if path.suffix.lower() == ".md"]


@mcp.tool()
def obsidian_vault_status(vault_path: str = "") -> dict[str, Any]:
    """Return basic information about a local Obsidian vault."""
    vault = _vault(vault_path)
    files = list(_iter_files(vault))
    md_count = sum(1 for path in files if path.suffix.lower() == ".md")
    canvas_count = sum(1 for path in files if path.suffix.lower() == ".canvas")
    base_count = sum(1 for path in files if path.suffix.lower() == ".base")
    return {
        "vaultPath": str(vault),
        "hasObsidianConfig": (vault / ".obsidian").exists(),
        "fileCount": len(files),
        "markdownCount": md_count,
        "canvasCount": canvas_count,
        "baseCount": base_count,
        "cliAvailable": shutil.which(os.environ.get("OBSIDIAN_CLI_COMMAND", "obsidian")) is not None,
    }


@mcp.tool()
def obsidian_list_files(
    vault_path: str = "",
    folder: str = "",
    extensions: str = ".md,.canvas,.base",
    include_hidden: bool = False,
    limit: int = 200,
) -> list[dict[str, Any]]:
    """List vault files, optionally filtered by folder and comma-separated extensions."""
    vault = _vault(vault_path)
    wanted = _extension_set(extensions)
    rows: list[dict[str, Any]] = []
    for path in _iter_files(vault, folder, include_hidden):
        if wanted and path.suffix.lower() not in wanted:
            continue
        stat = path.stat()
        rows.append(
            {
                "path": _rel(vault, path),
                "name": path.name,
                "extension": path.suffix.lstrip("."),
                "size": stat.st_size,
                "modified": int(stat.st_mtime),
            }
        )
        if len(rows) >= max(1, limit):
            break
    return rows


@mcp.tool()
def obsidian_search(
    query: str,
    vault_path: str = "",
    folder: str = "",
    extensions: str = ".md",
    case_sensitive: bool = False,
    limit: int = 50,
    context_chars: int = 140,
) -> list[dict[str, Any]]:
    """Search text files in a vault and return matching line snippets."""
    vault = _vault(vault_path)
    wanted = _extension_set(extensions)
    needle = query if case_sensitive else query.lower()
    matches: list[dict[str, Any]] = []
    for path in _iter_files(vault, folder):
        if wanted and path.suffix.lower() not in wanted:
            continue
        try:
            lines = _read_text(path).splitlines()
        except UnicodeDecodeError:
            continue
        for number, line in enumerate(lines, start=1):
            haystack = line if case_sensitive else line.lower()
            index = haystack.find(needle)
            if index == -1:
                continue
            start = max(0, index - context_chars // 2)
            end = min(len(line), index + len(query) + context_chars // 2)
            matches.append({"path": _rel(vault, path), "line": number, "snippet": line[start:end].strip()})
            if len(matches) >= max(1, limit):
                return matches
    return matches


@mcp.tool()
def obsidian_read_file(path: str, vault_path: str = "", max_chars: int = 20000) -> dict[str, Any]:
    """Read a vault-relative file and parse Markdown frontmatter when present."""
    vault = _vault(vault_path)
    full = _safe_path(vault, path)
    text = _read_text(full)
    properties, body = _split_frontmatter(text) if full.suffix.lower() == ".md" else ({}, text)
    truncated = len(text) > max_chars
    return {
        "path": _rel(vault, full),
        "exists": full.exists(),
        "properties": properties,
        "content": text[:max_chars],
        "body": body[:max_chars] if full.suffix.lower() == ".md" else text[:max_chars],
        "truncated": truncated,
    }


@mcp.tool()
def obsidian_write_file(
    path: str,
    content: str,
    vault_path: str = "",
    overwrite: bool = False,
) -> dict[str, Any]:
    """Write a vault-relative file. Existing files require overwrite=true."""
    vault = _vault(vault_path)
    full = _safe_path(vault, path)
    if full.exists() and not overwrite:
        return {"ok": False, "path": _rel(vault, full), "error": "File exists. Pass overwrite=true to replace it."}
    _write_text(full, content)
    return {"ok": True, "path": _rel(vault, full), "bytes": full.stat().st_size}


@mcp.tool()
def obsidian_create_note(
    path: str,
    title: str = "",
    body: str = "",
    properties_json: str = "{}",
    vault_path: str = "",
    overwrite: bool = False,
) -> dict[str, Any]:
    """Create a Markdown note with YAML properties."""
    vault = _vault(vault_path)
    rel_path = path if path.lower().endswith(".md") else f"{path}.md"
    full = _safe_path(vault, rel_path)
    if full.exists() and not overwrite:
        return {"ok": False, "path": _rel(vault, full), "error": "Note exists. Pass overwrite=true to replace it."}
    properties = _json(properties_json, {})
    if not isinstance(properties, dict):
        raise ValueError("properties_json must decode to an object.")
    note_title = title or properties.get("title") or _note_title_from_path(rel_path)
    properties.setdefault("title", note_title)
    content_body = body.strip()
    if content_body and not content_body.startswith("#"):
        content_body = f"# {note_title}\n\n{content_body}"
    elif not content_body:
        content_body = f"# {note_title}\n"
    _write_text(full, _join_frontmatter(properties, content_body))
    return {"ok": True, "path": _rel(vault, full), "properties": properties}


@mcp.tool()
def obsidian_update_properties(
    path: str,
    properties_json: str,
    vault_path: str = "",
    mode: str = "merge",
) -> dict[str, Any]:
    """Merge, replace, or remove YAML frontmatter properties on a Markdown note."""
    vault = _vault(vault_path)
    full = _safe_path(vault, path)
    text = _read_text(full)
    existing, body = _split_frontmatter(text)
    incoming = _json(properties_json, {})
    if not isinstance(incoming, dict):
        raise ValueError("properties_json must decode to an object.")
    if mode == "replace":
        updated = incoming
    elif mode == "remove":
        updated = dict(existing)
        for key in incoming:
            updated.pop(key, None)
    elif mode == "merge":
        updated = dict(existing)
        updated.update(incoming)
    else:
        raise ValueError("mode must be merge, replace, or remove.")
    _write_text(full, _join_frontmatter(updated, body))
    return {"ok": True, "path": _rel(vault, full), "properties": updated}


@mcp.tool()
def obsidian_add_wikilinks(
    path: str,
    links_json: str,
    vault_path: str = "",
    append_related: bool = True,
    replace_first_phrase: bool = False,
) -> dict[str, Any]:
    """Add wikilinks to a note by appending a related section or replacing exact phrases."""
    vault = _vault(vault_path)
    full = _safe_path(vault, path)
    text = _read_text(full)
    links = _json(links_json, [])
    if not isinstance(links, list):
        raise ValueError("links_json must decode to a list.")

    normalized_links: list[dict[str, str]] = []
    for item in links:
        if isinstance(item, str):
            normalized_links.append({"target": item, "label": ""})
        elif isinstance(item, dict) and item.get("target"):
            normalized_links.append({"target": str(item["target"]), "label": str(item.get("label") or ""), "phrase": str(item.get("phrase") or "")})

    changed = text
    replacements = 0
    if replace_first_phrase:
        for item in normalized_links:
            phrase = item.get("phrase") or item.get("label") or item["target"]
            link = f"[[{item['target']}|{phrase}]]" if phrase != item["target"] else f"[[{item['target']}]]"
            pattern = re.compile(rf"(?<!\[\[)\b{re.escape(phrase)}\b(?![^\[]*\]\])")
            changed, count = pattern.subn(link, changed, count=1)
            replacements += count

    appended: list[str] = []
    if append_related:
        existing_targets = {_target_from_link(match.group(1)).lower() for match in WIKILINK_RE.finditer(changed)}
        for item in normalized_links:
            target = item["target"]
            if _target_from_link(target).lower() in existing_targets:
                continue
            label = item.get("label") or target
            link = f"[[{target}|{label}]]" if label != target else f"[[{target}]]"
            appended.append(f"- {link}")
        if appended:
            section = "\n\n## Related\n\n" + "\n".join(appended) + "\n"
            changed = changed.rstrip() + section

    _write_text(full, changed)
    return {"ok": True, "path": _rel(vault, full), "replacements": replacements, "appended": appended}


@mcp.tool()
def obsidian_build_graph(
    vault_path: str = "",
    folder: str = "",
    include_tags: bool = True,
    write_json_path: str = "",
) -> dict[str, Any]:
    """Build graph data from Markdown wikilinks, embeds, frontmatter tags, and backlinks."""
    vault = _vault(vault_path)
    md_files = [path for path in _iter_files(vault, folder) if path.suffix.lower() == ".md"]
    known_by_key: dict[str, str] = {}
    for path in md_files:
        rel_path = _rel(vault, path)
        known_by_key[_normalize_note_key(rel_path)] = rel_path
        known_by_key[_normalize_note_key(path.stem)] = rel_path

    nodes: dict[str, dict[str, Any]] = {}
    edges: list[dict[str, Any]] = []
    unresolved: dict[str, list[str]] = {}
    outgoing: dict[str, set[str]] = {}
    incoming: dict[str, set[str]] = {}
    tag_counts: dict[str, int] = {}

    for path in md_files:
        rel_path = _rel(vault, path)
        text = _read_text(path)
        props, _ = _split_frontmatter(text)
        nodes[rel_path] = {"id": rel_path, "type": "note", "title": props.get("title") or path.stem, "tags": props.get("tags", [])}
        outgoing.setdefault(rel_path, set())
        incoming.setdefault(rel_path, set())
        for tag in props.get("tags", []) if isinstance(props.get("tags", []), list) else []:
            tag_counts[str(tag)] = tag_counts.get(str(tag), 0) + 1
        for regex, kind in [(WIKILINK_RE, "wikilink"), (EMBED_RE, "embed")]:
            for match in regex.finditer(text):
                raw_target = _target_from_link(match.group(1))
                target_rel = known_by_key.get(_normalize_note_key(raw_target))
                if target_rel:
                    edges.append({"source": rel_path, "target": target_rel, "kind": kind})
                    outgoing[rel_path].add(target_rel)
                    incoming.setdefault(target_rel, set()).add(rel_path)
                else:
                    unresolved.setdefault(raw_target, []).append(rel_path)

    orphans = sorted([node_id for node_id in nodes if not incoming.get(node_id)])
    dead_ends = sorted([node_id for node_id in nodes if not outgoing.get(node_id)])
    result: dict[str, Any] = {
        "vaultPath": str(vault),
        "nodeCount": len(nodes),
        "edgeCount": len(edges),
        "nodes": list(nodes.values()),
        "edges": edges,
        "orphans": orphans,
        "deadEnds": dead_ends,
        "unresolved": unresolved,
    }
    if include_tags:
        result["tags"] = [{"tag": tag, "count": count} for tag, count in sorted(tag_counts.items())]
    if write_json_path:
        output = _safe_path(vault, write_json_path)
        _write_text(output, json.dumps(result, ensure_ascii=False, indent=2))
        result["writtenTo"] = _rel(vault, output)
    return result


@mcp.tool()
def obsidian_create_canvas(
    path: str,
    nodes_json: str,
    edges_json: str = "[]",
    vault_path: str = "",
    overwrite: bool = False,
) -> dict[str, Any]:
    """Create a JSON Canvas file from node and edge JSON arrays."""
    vault = _vault(vault_path)
    rel_path = path if path.lower().endswith(".canvas") else f"{path}.canvas"
    full = _safe_path(vault, rel_path)
    if full.exists() and not overwrite:
        return {"ok": False, "path": _rel(vault, full), "error": "Canvas exists. Pass overwrite=true to replace it."}
    nodes = _json(nodes_json, [])
    edges = _json(edges_json, [])
    if not isinstance(nodes, list) or not isinstance(edges, list):
        raise ValueError("nodes_json and edges_json must decode to arrays.")
    node_ids = {node.get("id") for node in nodes if isinstance(node, dict)}
    if len(node_ids) != len(nodes):
        raise ValueError("Every Canvas node needs a unique id.")
    for edge in edges:
        if not isinstance(edge, dict):
            raise ValueError("Each edge must be an object.")
        if edge.get("fromNode") not in node_ids or edge.get("toNode") not in node_ids:
            raise ValueError(f"Canvas edge references missing node: {edge}")
    payload = {"nodes": nodes, "edges": edges}
    _write_text(full, json.dumps(payload, ensure_ascii=False, indent=2))
    return {"ok": True, "path": _rel(vault, full), "nodeCount": len(nodes), "edgeCount": len(edges)}


@mcp.tool()
def obsidian_create_base(
    path: str,
    base_json: str,
    vault_path: str = "",
    overwrite: bool = False,
) -> dict[str, Any]:
    """Create an Obsidian Bases .base file from a JSON object."""
    vault = _vault(vault_path)
    rel_path = path if path.lower().endswith(".base") else f"{path}.base"
    full = _safe_path(vault, rel_path)
    if full.exists() and not overwrite:
        return {"ok": False, "path": _rel(vault, full), "error": "Base exists. Pass overwrite=true to replace it."}
    base = _json(base_json, {})
    if not isinstance(base, dict):
        raise ValueError("base_json must decode to an object.")
    _write_text(full, _dump_yaml(base) + "\n")
    return {"ok": True, "path": _rel(vault, full), "topLevelKeys": list(base.keys())}


@mcp.tool()
def obsidian_cli(
    command: str,
    params_json: str = "{}",
    flags_json: str = "[]",
    vault: str = "",
    cwd: str = "",
    timeout_seconds: int = 30,
) -> dict[str, Any]:
    """Call the local Obsidian CLI with parameter and flag JSON."""
    cli = os.environ.get("OBSIDIAN_CLI_COMMAND", "obsidian")
    if shutil.which(cli) is None:
        return {"ok": False, "error": f"Obsidian CLI command not found on PATH: {cli}"}
    params = _json(params_json, {})
    flags = _json(flags_json, [])
    if not isinstance(params, dict):
        raise ValueError("params_json must decode to an object.")
    if not isinstance(flags, list):
        raise ValueError("flags_json must decode to an array.")
    args = [cli]
    if vault:
        args.append(f"vault={vault}")
    if command:
        args.append(command)
    for key, value in params.items():
        args.append(f"{key}={value}")
    for flag in flags:
        args.append(str(flag))
    run_cwd = str(_vault(cwd)) if cwd else None
    completed = subprocess.run(
        args,
        cwd=run_cwd,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        timeout=max(1, timeout_seconds),
    )
    return {
        "ok": completed.returncode == 0,
        "command": args,
        "returnCode": completed.returncode,
        "stdout": completed.stdout,
        "stderr": completed.stderr,
    }


if __name__ == "__main__":
    mcp.run()
