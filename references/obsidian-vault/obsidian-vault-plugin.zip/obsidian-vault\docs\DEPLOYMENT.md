# Deployment Guide

This plugin can be shared as a local Codex plugin directory or published through a GitHub repository.

## Current Blocker in This Workspace

The current workspace is not a git repository, and GitHub CLI is not installed:

- `git rev-parse --is-inside-work-tree` returns `not-git`.
- `gh` is not available on `PATH`.

Because of that, the plugin can be prepared locally, but it cannot be pushed to GitHub from this machine until GitHub publishing tools are configured.

## Recommended Repository Layout

Publish the plugin root directly:

```text
obsidian-vault/
  .codex-plugin/plugin.json
  .mcp.json
  README.md
  requirements.txt
  assets/screenshots/
  docs/
  scripts/obsidian_vault_mcp.py
  skills/obsidian-vault/SKILL.md
```

## GitHub CLI Publishing Flow

Install and authenticate GitHub CLI:

```powershell
winget install GitHub.cli
gh auth login
gh auth status
```

Create and push a repository from this plugin directory:

```powershell
Set-Location "<path-to-your-plugin>\obsidian-vault"
git init
git add .codex-plugin .mcp.json README.md requirements.txt assets docs scripts skills
git commit -m "publish obsidian vault codex plugin"
gh repo create obsidian-vault --public --source . --remote origin --push
```

If you prefer a private repository:

```powershell
gh repo create obsidian-vault --private --source . --remote origin --push
```

After creating the repository, update `.codex-plugin/plugin.json`:

```json
{
  "repository": "https://github.com/<owner>/obsidian-vault"
}
```

Then commit and push that metadata update.

## Manual Publishing Flow

If GitHub CLI is unavailable:

1. Create a new repository on GitHub named `obsidian-vault`.
2. Open a terminal in `plugins/obsidian-vault`.
3. Run:

```powershell
git init
git add .codex-plugin .mcp.json README.md requirements.txt assets docs scripts skills
git commit -m "publish obsidian vault codex plugin"
git branch -M main
git remote add origin https://github.com/<owner>/obsidian-vault.git
git push -u origin main
```

## Release Checklist

- Replace `https://github.com/your-org/obsidian-vault` in `.codex-plugin/plugin.json`.
- Replace local author metadata if publishing under a real organization.
- Verify `python -m pip install -r requirements.txt` on a clean machine.
- Test with `OBSIDIAN_VAULT_PATH=auto`.
- Test with an explicit vault path containing non-ASCII characters.
- Confirm Obsidian 1.12.7 or newer is running for CLI-backed features.
- Confirm Obsidian core plugins `bases`, `canvas`, and `properties` are enabled.
